
import javax.swing.JOptionPane;  // importando uma classe pré existente no java
import java.lang.Math; // importando uma classe pré existente no java
/*
 * @author Guilherme O Santos
 */
public class Prova_Bubble{    //declaração da classe com o nome identico ao do projeto
    static int i, j, aux, menu, option; //declarando variáveis do tipo INTEIRO
    static int vet[] = new int[10]; // declarando um vetor do tipo INTEIRO

    public static void main(String[] args) { //método principal

        Inserir(); //Chamando o método inserir 

        do { //estrutura de decisão FAÇA
            menu = Integer.parseInt(JOptionPane.showInputDialog("INSIRA O Nº CORRESPONDENTE A OPERAÇAO:\n\n" //Introduçao de dados na variável de controle MENU através de uma interface.
                    + "1 - Ordenar em ordem Crescente.\n"
                    + "2 - Ordenar em ordem Decrescente.\n"
                    + "3 - Inserir novos valores.\n"
                    + "4 - Simular novos valores\n"
                    + " 9 - Sair."));   // Opçoes correspondentes a estrutura de decisão SWITCH abaixo.

            switch (menu) { // estrutura de decisão SWITCH

                case (1) -> //Opção 1
                    OrdenaCrescente();
                //finaliza a opção
                 //Chamando o método OrdenaCrescente
                case (2) -> //Opção 2
                    OrdenaDecrescente();
                //finaliza a opção
                 //Chamando o método OrdenaDecrescente
                case (3) -> //Opção 3
                    InserirValor();
                //finaliza a opção
                 //Chamando o método InserirValor
                case (4) -> //Opção 4
                    Random();
                //finaliza a opção
                 //Chamando o método Random
                case (9) -> //Opção 5
                    System.exit(0);
                //finaliza a opção
                 //Chamando o método exit da classe system (classe.método = System.exit())
            }
            // estrutura de decisão SWITCH
            //fim do switch


        } while (menu != 9); //estrutura de decisão while associada ao DO, DO WHILE ( faça enquanto a condiçao for verdadeira)
        //fim do DO.
    }//fim do método principal

    /*método para inserir dados no vetor vet[]
     * dando a opção de escolher os numeros
     * ou sortia-los.
     */
    private static void Inserir() { //declaraçao do metodo Inserir
        while (option != 1 && option != 2) { //estrutura de decisao While (Enquanto)
            option = Integer.parseInt(JOptionPane.showInputDialog("INSIRA O Nº CORRESPONDENTE A OPERAÇAO:\n\n"//Introduçao de dados na variável de controle OPTION através de uma interface.
                    + "1 - Inserir novos valores\n"
                    + "2 - Simular novos valor"));// Opçoes correspondentes a estrutura de decisão SWITCH abaixo.
            switch (option) {// estrutura de decisão SWITCH
                case (1) -> InserirValor();
                //finaliza a opção
                //Chamando o método InserirValor
                case (2) -> Random();
                //finaliza a opção
                 //Chamando o método Random 

            }
            // estrutura de decisão SWITCH
            //fim do switch
        }// fim do while (enquanto)
    }//fim do metodo Inserir()

    /*
     *metodo para inserir valores manualmente no vetor vet[] 
     */
    private static void InserirValor() { //declaraçao do metodo Inserir
        for (i = 0; i < (vet.length); i++) { //estrutura de decisao FOR ( para ) 
            aux = i + 1;// atribuiçao do valor de i + 1 na variavel aux
            vet[i] = Integer.parseInt(JOptionPane.showInputDialog("insira o " + aux + "º valor:"));//Introduçao de dados no vetor vet[i] tendo i como indice.
        }//fim da estrutura for
        JOptionPane.showMessageDialog(null, "os valores são: ["// exibiçao de dados atravez de uma interface
                + vet[0] + "," + vet[1] + "," + vet[2] + "," + vet[3] + "," + vet[4] + "," + vet[5] + "," + vet[6] + "," + vet[7] + "," + vet[8] + "," + vet[9] + "]");

    }//fim do metodo InserirValor()

    /*
     * metodo para inserir valores sortidos no vetor vet[]
     */
    private static void Random() {//declaraçao do metodo Random()
        long aux2 = 0;//declaraçao de variavel local do tipo LONG
        for (i = 0; i < (vet.length); i++) {//estrutura de decisao FOR ( para ) 
            aux2 = Math.round(Math.random() * 100); // atribuiçao de um valor sortido a variavel aux2
            vet[i] = (int) aux2;//atribuiçao do valor de aux2 para vet[] de indice i. (int) serve para forçar o valor a ser um INTEIRO
        }//fim da estrutura for
        JOptionPane.showMessageDialog(null, "os valores são: ["// exibiçao de dados atravez de uma interface
                + aux2 + "" + vet[0] + "," + vet[1] + "," + vet[2] + "," + vet[3] + "," + vet[4] + "," + vet[5] + "," + vet[6] + "," + vet[7] + "," + vet[8] + "," + vet[9] + "]");
    }//fim do metodo Random()

    /*
     * metodo para ordenar os valores do vetor vet[] em ordem crescente
     */
    public static void OrdenaCrescente() {//declaraçao do metodo OrdenaCrescente
        for (i = 0; i < (vet.length)-1; i++) {//estrutura de decisao FOR ( para ) 
            for (j = i + 1; j < (vet.length); j++) {//estrutura de decisao FOR ( para ) 
                if (vet[i] > vet[j]) {//estrutura de decisao IF ( se(condiçao) ) se atender a condiçao executa todo o código dentro da estrutura 
                    aux = vet[i];// aux recebe o valor do vet[] de indice i
                    vet[i] = vet[j];// vet[] de indice i recebe o valor do vet[] de indice j
                    vet[j] = aux;// vet[] de indice j recebe o valor do aux ( que era o valor do vet[] de indice i
                }//fim da estrutura IF (se)
            }//fim da estrutura for de indice j
        }//fim da estrutura for de indice i
        JOptionPane.showMessageDialog(null, "Os valores em Ordem Crescente: ["// exibiçao dos dados atravez de uma interface
                + vet[0] + "," + vet[1] + "," + vet[2] + "," + vet[3] + "," + vet[4] + "," + vet[5] + "," + vet[6] + "," + vet[7] + "," + vet[8] + "," + vet[9] + "]");

    }//fim do metoro OrdenaCrescente()

    /*metoro para ordenar os valores do vetor vet[] em ordem decrescente
     *
     */
    public static void OrdenaDecrescente() {//declaraçao do metodo OrdenaDecrescente
        for (i = 0; i < (vet.length)-1; i++) {//estrutura de decisao FOR ( para ) 
            for (j = i + 1; j < (vet.length); j++) {//estrutura de decisao FOR ( para ) 
                if (vet[i] < vet[j]) {//estrutura de decisao IF ( se(condiçao) ) se atender a condiçao executa todo o código dentro da estrutura 
                    aux = vet[i];// aux recebe o valor do vet[] de indice i
                    vet[i] = vet[j];// vet[] de indice i recebe o valor do vet[] de indice j
                    vet[j] = aux;// vet[] de indice j recebe o valor do aux ( que era o valor do vet[] de indice i
                }//fim da estrutura IF (se)
            }//fim da estrutura for de indice j
        }//fim da estrutura for de indice i

        JOptionPane.showMessageDialog(null, "Os valores em Ordem Decrescente: ["// exibiçao dos dados atravez de uma interface
                + vet[0] + "," + vet[1] + "," + vet[2] + "," + vet[3] + "," + vet[4] + "," + vet[5] + "," + vet[6] + "," + vet[7] + "," + vet[8] + "," + vet[9] + "]");

    }//fim do metodo OrdenaDecrescente
}//fim da classe Ordem
